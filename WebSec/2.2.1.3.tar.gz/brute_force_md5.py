import hashlib
import string
import re

s = ""
print(string.ascii_letters)
validLetters = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
'1','2','3','4','5','6','7','8','9','0']

# based on https://www.geeksforgeeks.org/print-all-combinations-of-given-length/
def checkAllKLength(set, k):
 
    n = len(set)
    checkAllKLengthRec(set, "", n, k)
 
def checkAllKLengthRec(set, prefix, n, k):
     
    # Base case: k is 0,
    # print prefix
    if (k == 0) :
        strHash = hashlib.md5(prefix.encode('utf-8')).hexdigest()
        if ("273c3123" in strHash or # variations of '<1#
            "273c3223" in strHash or
            "273c3323" in strHash or
            "273c3423" in strHash or
            "273c3523" in strHash or
            "273c3623" in strHash or
            "273c3723" in strHash or
            "273c3823" in strHash or
            "273c3923" in strHash or
            re.search('.*276f72273[1-9].*', strHash) is not None or # variations of 'or'1
            re.search('.*277c7c273[1-9].*', strHash) is not None # variations of '||'1
            ):
            print(prefix)
        return
 
    # One by one add all characters
    # from set and recursively
    # call for k equals to k-1
    for i in range(n):
        # Next character of input added
        newPrefix = prefix + set[i]
         
        # k is decreased, because
        # we have added a new character
        checkAllKLengthRec(set, newPrefix, n, k - 1)

checkAllKLength(validLetters, 128)
print("Done")
